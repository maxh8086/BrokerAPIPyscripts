from py5paisa import FivePaisaClient
from credentials import *
client = FivePaisaClient(email=email, passwd=pwd, dob=dob)
client.login()

req_list=[
            { "Exch":"M","ExchType":"D","ScripCode":228031  },
             { "Exch":"M","ExchType":"D","ScripCode":224570}, { "Exch":"M","ExchType":"D","ScripCode":231036}
            
            ]

dict1=client.Request_Feed('mf','s',req_list)

client.Streming_data(dict1)