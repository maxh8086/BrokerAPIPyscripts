
from py5paisa import FivePaisaClient
import json
import websocket
from credentials import *

class FivePaisaClientv2(FivePaisaClient):
    def Streming_data(self,wsPayload : dict):
            self.web_url=f'wss://openfeed.5paisa.com/Feeds/api/chat?Value1={self.Jwt_token}|{self.client_code}'
            auth=self.Login_check()

            def on_message(ws, message):
                print('MY DATA', message)
            
            def on_error(ws, error):
                print(error)
                
            def on_close(ws):
                print("Streaming Stopped")
            
            def on_open(ws):
                print("Streaming Started")
                ws.send(json.dumps(wsPayload))
            
                
            ws = websocket.WebSocketApp(self.web_url,
                                on_open=on_open,
                                on_message = on_message,
                                on_error = on_error,
                                on_close = on_close,
                                cookie=auth)
            
            ws.run_forever()



client = FivePaisaClientv2(email=email, passwd=pwd, dob=dob)
client.login()

req_list=[
            { "Exch":"M","ExchType":"D","ScripCode":228031  },
             { "Exch":"M","ExchType":"D","ScripCode":224570}, { "Exch":"M","ExchType":"D","ScripCode":231036}
            
            ]

dict1=client.Request_Feed('mf','s',req_list)

client.Streming_data(dict1)
        
