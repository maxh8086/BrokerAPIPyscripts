

email = 'yourmail@gmail.com'
pwd = 'password'
dob="19951231"



cred={
    "APP_NAME":"34567",
    "APP_SOURCE":"76R",
    "USER_ID":"87654G",
    "PASSWORD":"JUHGF65",
    "USER_KEY":"ghjKAf678ijdkjn,",
    "ENCRYPTION_KEY":"FFMDJKMD67890pmd677"
    }



















































































