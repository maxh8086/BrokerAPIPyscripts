from py5paisa import FivePaisaClient
from credentials import *

from py5paisa.strategy import *



strategy=strategies(user=email, passw=pwd, dob=dob,cred=cred)

strategy.iron_condor("NIFTY",["15000","15200"],["15100","15150"],"50","20210826","I")


