import enum

class Credentials(enum.Enum):
    UserName = 'usrname'
    PassWord = 'pwd'
    SecretKey = 'secretkey'
    AppId = 'app_id'

