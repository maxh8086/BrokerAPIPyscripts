from alice_blue import *
from config import Credentials
import datetime
import time
from time import strftime, localtime
import pandas as pd
import threading
from orderClass import place_order


TRADED_SCRIPT = ['BHEL','PNB']  # fno ban SCRIPTS
socket_opened = False
timeFrame = 10  # in seconds
spread_limit = 1

df = pd.DataFrame([],columns=['symbol', 'timestamp', 'spot_ltp','fut_ltp','lot_size','fut_symbol'])
df.set_index('symbol',inplace= True)

def event_handler_quote_update(message):
    ltp = message['best_ask_price']
    timestamp = datetime.datetime.fromtimestamp(message['exchange_time_stamp'])
    instrumnet = message['instrument'].symbol
    exchange = message['instrument'].exchange
    lot_size = message['instrument'].lot_size
    fut_symbol = instrumnet
    
    global df
    if exchange == 'NFO':
        instrumnet = instrumnet.split()[0]
        ltp = message['best_bid_price']

        
    
    
    if instrumnet in df.index and exchange == 'NFO':
        df.loc[instrumnet, ['fut_ltp','lot_size','fut_symbol','timestamp']] = [ltp,lot_size,fut_symbol,timestamp]
        
    elif  instrumnet in df.index and exchange == 'NSE':
        df.loc[instrumnet, ['spot_ltp','timestamp']] = [ltp,timestamp]
    else:
        new_row = pd.Series(data={ 'timestamp': timestamp,'spot_ltp': ltp,
                        'fut_ltp': ltp, 'lot_size':lot_size, 'fut_symbol':fut_symbol}, name=instrumnet)
        df = df.append(new_row, ignore_index=False)
    
 


def open_callback():
    global socket_opened
    socket_opened = True
    print("Socket opened")


def login():
    access_token = AliceBlue.login_and_get_access_token(username=Credentials.UserName.value, password=Credentials.PassWord.value, twoFA='a',
    api_secret=Credentials.SecretKey.value, app_id=Credentials.AppId.value)
    alice = AliceBlue(username=Credentials.UserName.value, password=Credentials.PassWord.value,
                      access_token=access_token, master_contracts_to_download=['NSE', 'NFO','MCX'])
   
    alice.start_websocket(subscribe_callback=event_handler_quote_update,
                          socket_open_callback=open_callback,
                          run_in_background=True)
   
    while(socket_opened == False):    # wait till socket open & then subscribe
        pass
    script_list = getScripList()
    #subscibe data
    for row in script_list.itertuples(index=False):
        fut_symbol = alice.get_instrument_for_fno(symbol = row.SYMBOL, expiry_date=datetime.datetime.date(row.EXPIRY_DT), is_fut=True, strike=None, is_CE = False)
        alice.subscribe(fut_symbol, LiveFeedType.MARKET_DATA) #subscribe futures
        alice.subscribe(alice.get_instrument_by_symbol('NSE', row.SYMBOL), LiveFeedType.MARKET_DATA) #subscribe spot
    return alice
   
    


def checkSpread(order_class):
    global spread_limit
    global TRADED_SCRIPT
    start = time.time()
    
    global df
    spread_df = df.copy(deep=True).drop_duplicates()  
    
    df = df[0:0]
    spread_df['gap'] = 100*(spread_df['fut_ltp'] - spread_df['spot_ltp']) / spread_df['fut_ltp']
    print(spread_df)
    spread_df = spread_df[spread_df['gap'] > spread_limit]
    print(spread_df)
    '''for row in spread_df.itertuples(index=True):
        if row.Index not in TRADED_SCRIPT: 
            print(row.fut_symbol,row.Index )
            response_fut = order_class.placeNRMLOrder(row.fut_symbol,'NFO',int(row.lot_size),TransactionType.Sell)
            response_spot = order_class.placeNRMLOrder(row.Index,'NSE',int(row.lot_size),TransactionType.Buy)
            print(response_fut, response_spot)
            TRADED_SCRIPT.append(row.Index)'''

    interval = timeFrame - (time.time() - start)
    print(f"Next check will start after {interval} sec : {datetime.datetime.now()}")
    threading.Timer(interval, checkSpread,args=[order_class]).start()



def getScripList() :
    bhav = pd.read_csv('F:/demo_file/fno.csv',parse_dates = ['TIMESTAMP','EXPIRY_DT'])
    bhav = bhav[(bhav['INSTRUMENT'] == 'FUTSTK') & (bhav['EXPIRY_DT'] == '2021-04-29')]
    bhav = bhav[['SYMBOL','EXPIRY_DT']]
    bhav = bhav.tail(120)
    return bhav



if __name__ == '__main__':
    alice = login()
    order = place_order(alice)
    time.sleep(30)
    checkSpread(order)
    
