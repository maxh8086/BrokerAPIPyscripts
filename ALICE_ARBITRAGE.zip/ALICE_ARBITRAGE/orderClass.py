from alice_blue import *

class place_order :
    def __init__(self, alice):
        self.alice = alice
    
    def placeBracketOrder(self,symbol,exchange,qty,sl,target,limitp,trans_type):
        symbolInfo = self.alice.get_instrument_by_symbol(exchange, symbol)
        response = self.alice.place_order(transaction_type = trans_type,
                     instrument = symbolInfo,
                     quantity = qty,
                     order_type = OrderType.Limit,
                     product_type = ProductType.BracketOrder,
                     price = limitp,
                     trigger_price = None,
                     stop_loss = sl,
                     square_off = target,
                     trailing_sl = None,
                     is_amo = False)
        if response['status'] == 'sucess':
            orderId = response['data']['oms_order_id']
            return self.getOrderStatus(orderId)
            
        return response
    
    def placeNRMLOrder(self,symbol,exchange,qty,trans_type):
        symbolInfo = self.alice.get_instrument_by_symbol(exchange, symbol)
        response =self.alice.place_order(transaction_type = trans_type,
                     instrument = symbolInfo,
                     quantity = qty,
                     order_type = OrderType.Market,
                     product_type = ProductType.Delivery,
                     price = 0.0,
                     trigger_price = None,
                     stop_loss = None,
                     square_off = None,
                     trailing_sl = None,
                     is_amo = False)
        
        if response['status'] == 'success':
            orderId = response['data']['oms_order_id']
            return self.getOrderStatus(orderId)
            
        return response
    
    def getOrderStatus(self,orderId):
       response =  self.alice.get_order_history(orderId)
       if response['status'] == 'success':
            return  'order_status : '  + response['data'][0]['order_status']
            
