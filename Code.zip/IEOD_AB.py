import json
import pandas as pd
from datetime import datetime
eodjson = None
with open('F:\demo_file\AB_IEOD.json', 'r') as f:
        eodjson = json.load(f)
candelinfo = eodjson['data']
columns = ['timestamp','O','H','L','C','V']
df = pd.DataFrame(candelinfo, columns=columns)

df['timestamp']  = df.apply(lambda row:  datetime.fromtimestamp(row['timestamp']).isoformat(), axis=1)
df['timestamp'] = pd.to_datetime(df['timestamp']) 
df.to_csv('F:/demo_file/_ieod_1.csv', header =True,index = False )