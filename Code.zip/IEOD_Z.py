import json
import pandas as pd
eodjson = None
with open('F:\demo_file\KITE_IEOD.json', 'r') as f:
        eodjson = json.load(f)
candelinfo = eodjson['data']['candles']
columns = ['timestamp','O','H','L','C','V','OI']
df = pd.DataFrame(candelinfo, columns=columns)

df['timestamp'] = pd.to_datetime(df['timestamp'],format = '%Y-%m-%dT%H:%M:%S') 
df.to_csv('F:/demo_file/kite_ieod_1.csv', header =True,index = False )