
from NorenApi import  NorenApi
import pyotp
class ShoonyaApiPy(NorenApi):
    def __init__(self):
        NorenApi.__init__(self, host='https://api.shoonya.com/NorenWClientTP/',websocket='wss://api.shoonya.com/NorenWSTP/')
        
api = ShoonyaApiPy()  

credentials ={
    'user'        : '',
    'pwd'         : '',
    'totp_key'    :'',
    'app_key'     : ''
}

res=api.login(userid=credentials['user'], password=credentials['pwd'], twoFA=pyotp.TOTP(credentials['totp_key']).now(), vendor_code=credentials['user']+'_U', 
                api_secret=credentials['app_key'], imei=' cx6ns7kla')
print('Login ', res)



res = api.place_gtt_order( 'B', 'I',
                    'MCX', 'SILVERMIC28APR23', 1, 'LTP_B_O' ,67500,
                    "LMT", price=67490,
                    )
print(res)
gttOrders = api.get_enabledGTTOrders()
print(gttOrders)