from smartapi import SmartConnect
import threading
import pyotp,time
from config import  *
from datetime import datetime

obj=SmartConnect(api_key=apikey)
data = obj.generateSession(username,pwd,pyotp.TOTP(token).now())
print(data)
AUTH_TOKEN = data['data']['jwtToken']
refreshToken= data['data']['refreshToken']
FEED_TOKEN=obj.getfeedToken()
res = obj.getProfile(refreshToken)
print(res)



#------- Websocket code

from SmartWebsocketv2 import SmartWebSocketV2
correlation_id = "dft_test1"
action = 1
mode = 3


token_list = [{"exchangeType": 5, "tokens": ["242738" ,"244999"]}]  # ,

sws = SmartWebSocketV2(AUTH_TOKEN, apikey, username, FEED_TOKEN)


def on_data(wsapp, msg):
    try:
        #print("Ticks: {}".format(msg))
        LIVE_FEED_JSON[msg['token']] = {'token' :msg['token'] , 'ltp':msg['last_traded_price']/100 , 'exchange_timestamp':  datetime.fromtimestamp(msg['exchange_timestamp']/1000).isoformat() ,'oi':msg['open_interest']}
    except Exception as e:
        print(e)


def on_open(wsapp):
    print("on open")
    sws.subscribe(correlation_id, mode, token_list)


def on_error(wsapp, error):
    print(error)


def on_close(wsapp):
    print("Close")


# Assign the callbacks.
sws.on_open = on_open
sws.on_data = on_data
sws.on_error = on_error
sws.on_close = on_close


threading.Thread(target = sws.connect).start()

print('Control Released')
time.sleep(5)
print(LIVE_FEED_JSON)


while True:
    if LIVE_FEED_JSON['242738']['ltp'] > 68510:
        print('Entry trigger' , LIVE_FEED_JSON['242738']['ltp'])
        break
    
    print(LIVE_FEED_JSON)
    time.sleep(2)



time.sleep(100)
sws.close_connection()
print(f'Closed')



"""
{'subscription_mode': 3, 'exchange_type': 2, 'token': '49697', 'sequence_number': 31482369, 
'exchange_timestamp': 1673337615000, 
'last_traded_price': 16030, 'subscription_mode_val': 'SNAP_QUOTE', 'last_traded_quantity': 50, 
'average_traded_price': 19249, 'volume_trade_for_the_day': 9622600, 
'total_buy_quantity': 145350.0, 'total_sell_quantity': 206000.0, 'open_price_of_the_day': 25090, 
'high_price_of_the_day': 32360, 'low_price_of_the_day': 14535, 
'closed_price': 32125, 'last_traded_timestamp': 1673337615, 'open_interest': 1362050, 
'open_interest_change_percentage': 4612141548726607190, 
'upper_circuit_limit': 95080, 'lower_circuit_limit': 5, '52_week_high_price': 54635, 
'52_week_low_price': 0, 
'best_5_buy_data': [{'flag': 0, 'quantity': 250, 'price': 16030, 'no of orders': 1},
 {'flag': 0, 'quantity': 500, 'price': 16035, 'no of orders': 2},
 {'flag': 0, 'quantity': 1650, 'price': 16040, 'no of orders': 7}, 
 {'flag': 0, 'quantity': 950, 'price': 16045, 'no of orders': 4}, {'flag': 
0, 'quantity': 850, 'price': 16050, 'no of orders': 5}], 
'best_5_sell_data': [{'flag': 1, 'quantity': 200, 'price': 15995, 'no of orders': 1},
 {'flag': 1, 'quantity': 650, 'price': 15990, 'no of orders': 5},
 {'flag': 1, 'quantity': 450, 'price': 15985, 'no of orders': 3}, 
 {'flag': 1, 'quantity': 700, 'price': 15980, 'no of orders': 2},
  {'flag': 1, 'quantity': 1400, 'price': 15975, 'no of orders': 7}]}


"""











































