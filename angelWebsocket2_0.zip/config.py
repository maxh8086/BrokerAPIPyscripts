import pytz
from datetime import datetime
TIME_ZONE = pytz.timezone('Asia/Kolkata')
TZ_INFO = datetime.now(TIME_ZONE).tzinfo

API_KEY =    ''
USERNAME =  ''
PIN =       ''
TOKEN =     ''


SMART_API_OBJ =None
LIVE_FEED_JSON= {}
SMART_WEB = None
CORRELATION_ID = 'Wdn749NDjMfh23'  # ANY random string
FEED_MODE = 3 
