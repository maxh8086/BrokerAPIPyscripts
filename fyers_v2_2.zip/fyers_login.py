from fyers_api import fyersModel
from fyers_api.websocket import ws

from fyers_api import accessToken

import credentials
import time


client_id = credentials.client_id
secret_key = credentials.secret_key
redirect_uri = 'http://127.0.0.1:5000/'
session=accessToken.SessionModel(client_id=client_id,
secret_key=secret_key,redirect_uri=redirect_uri, 
response_type='code',grant_type='authorization_code')

auth_code = ''  #paste auth code here

session.set_token(auth_code)
response = session.generate_token()
print(response)
access_token = response["access_token"]
fyers = fyersModel.FyersModel(client_id=client_id, token=access_token,log_path="fv2/")
print(fyers.holdings())



def custom_message(self):
     print ("Custom " + str(self.response))    

"""ws.FyersSocket.websocket_data = custom_message
feedtoken = client_id + ":" + access_token
data_type = 'symbolData'
symbol =['MCX:CRUDEOIL21SEPFUT','MCX:SILVERMIC21NOVFUT']
fyersSocket = ws.FyersSocket(access_token=feedtoken, data_type=data_type,symbol=symbol)
fyersSocket.subscribe()
time.sleep(60)"""

feedtoken = client_id + ":" + access_token
ws.FyersSocket.websocket_data = custom_message
data_type = 'orderUpdate'
fyersSocket = ws.FyersSocket(access_token=feedtoken, data_type=data_type)
fyersSocket.subscribe()
time.sleep(120)