from smartapi import SmartConnect
from loggerConfig import  logger



def login():
    apikey = ''
    username = ''
    pwd = ''
    obj=SmartConnect(api_key=apikey)
    data = obj.generateSession(username,pwd)
    print(f"login status {data['status']} ")
    return obj


def getRmsLimit(obj):
    res = obj.rmsLimit()
    #print(res)
    logger.info(f'{res}')
   

def place_order(obj,token,symbol,qty,buy_sell,ordertype,price,variety= 'NORMAL',exch_seg='NSE',triggerprice=0):
    try:
        orderparams = {
            "variety": variety,
            "tradingsymbol": symbol,
            "symboltoken": token,
            "transactiontype": buy_sell,
            "exchange": exch_seg,
            "ordertype": ordertype,
            "producttype": "INTRADAY",
            "duration": "DAY",
            "price": price,
            "squareoff": "0",
            "stoploss": "0",
            "quantity": qty,
            "triggerprice":triggerprice,
            "ordertag":'DFT'
            }
        #print(orderparams)
        logger.info(f'{orderparams}')
        orderId=obj.placeOrder(orderparams)
        #print(f"The order id is: {orderId}")
        logger.info(f"The order id is: {orderId}")
    except Exception as e:
        logger.info("Order placement failed: {}".format(e.message))

obj = login()
getRmsLimit(obj)

ceordersRes = place_order(obj,83168,'NIFTY25AUG2217600CE',50,'SELL','MARKET',0,'NORMAL','NFO')

peordersRes = place_order(obj,83169,'NIFTY25AUG2217600PE',50,'SELL','MARKET',0,'NORMAL','NFO')
