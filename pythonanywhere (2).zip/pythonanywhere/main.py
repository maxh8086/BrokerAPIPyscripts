import pandas as pd
import numpy as np
from flask import *
app = Flask(__name__)


@app.route('/getDataTable')
def getDataTable() :
   
    df = pd.DataFrame({'A': np.linspace(1, 10, 10)})
    df = pd.concat([df, pd.DataFrame(np.random.randint(-50,50, size=(10, 4)), columns=list('BCDE'))],
                axis=1)
    result=  df.to_json(orient="records")
    parsed = json.loads(result)
    return jsonify(parsed)


@app.route('/')
def home() :
   
    return render_template('home.html')


if __name__ == "__main__":
    app.run(debug = True)