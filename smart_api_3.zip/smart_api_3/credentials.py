#replace  username,pwd, api_key  with yours
USER_NAME = '6565'
PWD = '6g!fdfgd'
API_KEY = '657hgg'

#Dont change  below varibale 
FEED_TOKEN = None
TOKEN_MAP = None
SMART_API_OBJ = None



