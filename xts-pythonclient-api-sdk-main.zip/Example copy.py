# from XTConnect import XTSConnect
from Connect import XTSConnect

# logging.basicConfig(level=logging.DEBUG)


API_KEY = ""
API_SECRET = ""
source = "WEBAPI"




xt = XTSConnect(API_KEY, API_SECRET, source)


response = xt.interactive_login()
print("Login: ", response)

"""Order book Request"""
response = xt.get_order_book()
print("Order Book: ", response)



API_KEY_M = ''
API_SECRET_M  =''
xtm = XTSConnect(API_KEY_M, API_SECRET_M, source)
response = xtm.marketdata_login()
print("MarketData Login: ", response)
instruments = [
    {'exchangeSegment': 1, 'exchangeInstrumentID': 2885},
    {'exchangeSegment': 1, 'exchangeInstrumentID': 22}]

response = xtm.get_quote(
    Instruments=instruments,
    xtsMessageCode=1504,
    publishFormat='JSON')
print('Quote :', response)


response = xtm.get_equity_symbol(
    exchangeSegment=1,
    series='EQ',
    symbol='Acc')
print('Equity Symbol:', str(response))

